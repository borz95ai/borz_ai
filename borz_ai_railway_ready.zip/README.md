# BORZ.AI Telegram Bot

## 🚀 Описание
Полностью автономный Telegram-бот с ИИ, системой управления, защитой и поддержкой Railway.

## ⚙️ Как развернуть
1. Установи переменные окружения:
   - `BOT_TOKEN` — токен Telegram-бота
   - `ADMIN_ID` — твой Telegram ID

2. Railway автоматически запустит `main.py` через Procfile.

3. Всё!

## 📦 Зависимости
Указаны в requirements.txt
